import json
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


# ----------------------------
# Load judgement dataset
# ----------------------------
with open("bail_judgments.json", "r", encoding="utf-8") as f:
    cases = json.load(f)

print(f"Loaded {len(cases)} cases")


# ----------------------------
# Prepare titles for similarity search
# ----------------------------
titles = [case.get("case_title", "") for case in cases]

vectorizer = TfidfVectorizer(stop_words="english")
title_vectors = vectorizer.fit_transform(titles)


# ----------------------------
# Search by Case Title
# ----------------------------
def search_by_title(title_query, top_k=3):
    query_vector = vectorizer.transform([title_query])
    similarities = cosine_similarity(query_vector, title_vectors)[0]

    top_indices = similarities.argsort()[-top_k:][::-1]

    results = []
    for idx in top_indices:
        case_data = cases[idx].copy()
        case_data["similarity_score"] = round(float(similarities[idx]), 4)
        results.append(case_data)

    return results


# ----------------------------
# Pretty Print Full Case
# ----------------------------
def print_case(case):
    print("=" * 80)
    print("Case ID:", case.get("case_id", "N/A"))
    print("Title:", case.get("case_title", "N/A"))
    print("Court:", case.get("court", "N/A"))
    print("Date:", case.get("date", "N/A"))
    print("Judge:", case.get("judge", "N/A"))
    print("Region:", case.get("region", "N/A"))
    print()

    print("IPC Sections:", ", ".join(case.get("ipc_sections", [])))
    print("Crime Type:", case.get("crime_type", "N/A"))
    print("Accused Name:", case.get("accused_name", "N/A"))
    print("Accused Gender:", case.get("accused_gender", "N/A"))
    print("Prior Cases:", case.get("prior_cases", "N/A"))
    print()

    print("Bail Type:", case.get("bail_type", "N/A"))
    print("Bail Outcome:", case.get("bail_outcome", "N/A"))
    print("Detailed Outcome:", case.get("bail_outcome_label_detailed", "N/A"))
    print("Landmark Case:", case.get("landmark_case", False))
    print("Bail Cancellation Case:", case.get("bail_cancellation_case", False))
    print("Parity Argument Used:", case.get("parity_argument_used", False))
    print("Bias Flag:", case.get("bias_flag", False))
    print()

    print("Facts:\n", case.get("facts", "N/A"))
    print()

    print("Legal Issues:")
    issues = case.get("legal_issues", [])
    if issues:
        for issue in issues:
            print(" -", issue)
    else:
        print(" N/A")
    print()

    print("Judgment Reason:\n", case.get("judgment_reason", "N/A"))
    print()

    print("Legal Principles:")
    principles = case.get("legal_principles_discussed", [])
    if principles:
        for p in principles:
            print(" -", p)
    else:
        print(" N/A")
    print()

    print("Summary:\n", case.get("summary", "N/A"))
    print()

    print("Source File:", case.get("source_filename", "N/A"))
    print("Similarity Score:", case.get("similarity_score", "N/A"))
    print("=" * 80)
    print()


# ----------------------------
# User Input
# ----------------------------
if __name__ == "__main__":
    print("\n🔍 Search Judgement By Case Title")
    user_input = input("Enter case title keywords: ")

    results = search_by_title(user_input)

    print("\n📚 Top Matching Cases:\n")
    for res in results:
        print_case(res)
