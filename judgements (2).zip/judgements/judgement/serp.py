import json
import requests
import datetime
import re
import os
from typing import List, Optional
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
from transformers import pipeline
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Pt
import pandas as pd
import re

try:
    from groq import Groq as GroqClient
except Exception:
    GroqClient = None



def _read_env_value_from_file(file_path: str, key: str) -> Optional[str]:
    if not os.path.exists(file_path):
        return None

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            for raw_line in f:
                line = raw_line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                if k.strip() != key:
                    continue
                value = v.strip().strip('"').strip("'")
                return value or None
    except Exception:
        return None

    return None


def _get_gemini_api_key() -> Optional[str]:
    key = os.getenv("GEMINI_API_KEY", "").strip()
    if key:
        return key

    # Also support local files for convenience in development.
    key = _read_env_value_from_file(".env", "GEMINI_API_KEY")
    if key:
        return key

    key = _read_env_value_from_file(".env.example", "GEMINI_API_KEY")
    if key:
        return key

    return None

def _get_groq_api_key() -> Optional[str]:
    key = os.getenv("GROQ_API_KEY", "").strip()
    if key:
        return key
    key = _read_env_value_from_file(".env", "GROQ_API_KEY")
    if key:
        return key
    key = _read_env_value_from_file(".env.example", "GROQ_API_KEY")
    return key or None


def _groq_chat_response(question: str, lines: List[str]) -> tuple[Optional[str], Optional[str]]:
    api_key = _get_groq_api_key()
    if not api_key:
        return None, "missing_groq_api_key"
    if GroqClient is None:
        return None, "groq_sdk_not_installed"

    prompt = (
        "You are a knowledgeable legal awareness assistant for Indian law (IPC - Indian Penal Code). "
        "Answer the user's question using the IPC section data provided below. "
        "Be concise, factual, and helpful. Do not fabricate any legal information not in the context. "
        "End with: 'Note: Please consult a qualified advocate for legal advice specific to your case.'\n\n"
        "IPC Section Data:\n---\n"
        + "\n\n".join(lines)
        + "\n---\n\nUser Question: "
        + question
    )

    try:
        client = GroqClient(api_key=api_key)
        chat = client.chat.completions.create(
            messages=[
                {"role": "system", "content": "You are a legal awareness assistant for Indian IPC law. Be factual, concise, and always recommend consulting a qualified advocate."},
                {"role": "user", "content": prompt}
            ],
            model="llama-3.3-70b-versatile",
            temperature=0.3,
            max_tokens=600,
        )
        text = chat.choices[0].message.content.strip()
        if text:
            return text, None
    except Exception as e:
        return None, f"groq_error: {str(e)[:80]}"

    return None, "groq_empty_response"

# Load punishments CSV - NEW
punishments_df = pd.read_csv("ipc_sections_filled.csv")
punishments = dict(zip(punishments_df['Section'].str.replace('IPC_', ''), punishments_df['Punishment']))

MISSING_PUNISHMENT_TOKENS = {"", "n/a", "na", "none", "null", "nan", "-"}
WORD_TO_NUMBER = {
    "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
    "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
    "eleven": 11, "twelve": 12, "thirteen": 13, "fourteen": 14,
    "fifteen": 15, "sixteen": 16, "seventeen": 17, "eighteen": 18,
    "nineteen": 19, "twenty": 20
}
CROSS_REFERENCE_SEVERITY = {
    "same as offence": 6.5,
    "as for false evidence": 8.2,
    "same as for forgery": 7.0,
    "as for kidnapping or abduction": 8.2,
    "being a thug": 8.5,
}


def _extract_max_imprisonment_months(pun_lower: str) -> Optional[float]:
    months = []

    # Numeric terms: "6 months", "10 years", OCR-noisy "6n month".
    for h in re.findall(r'(\d+)\s*[a-z]?\s*hour[s]?', pun_lower):
        months.append(float(h) / (24 * 30))
    for d in re.findall(r'(\d+)\s*[a-z]?\s*day[s]?', pun_lower):
        months.append(float(d) / 30)
    for m in re.findall(r'(\d+)\s*[a-z]?\s*month[s]?', pun_lower):
        months.append(float(m))
    for y in re.findall(r'(\d+)\s*[a-z]?\s*year[s]?', pun_lower):
        months.append(float(y) * 12)

    # Worded terms: "six months", "ten years".
    for word, value in WORD_TO_NUMBER.items():
        if re.search(rf'\b{word}\b\s*month[s]?', pun_lower):
            months.append(float(value))
        if re.search(rf'\b{word}\b\s*year[s]?', pun_lower):
            months.append(float(value) * 12)

    return max(months) if months else None


def _duration_to_severity(max_months: float) -> float:
    # Calibrated to avoid under-scoring short imprisonment while preserving scale.
    if max_months <= 0.25:  # up to ~1 week
        return 1.8
    if max_months <= 1:  # up to 1 month
        return 2.2
    if max_months <= 3:
        return 2.5
    if max_months <= 6:
        return 4.0
    if max_months <= 12:
        return 5.0
    if max_months <= 36:
        return 6.5
    if max_months <= 60:
        return 7.5
    if max_months <= 84:
        return 8.2
    if max_months <= 120:
        return 9.0
    return 9.5


def get_severity(pun: str) -> tuple[str, float]:
    if pd.isna(pun):
        return "N/A", 0.0

    pun_text = str(pun).strip()
    if pun_text.lower() in MISSING_PUNISHMENT_TOKENS:
        return "N/A", 0.0

    pun_lower = pun_text.lower()

    if "definitional" in pun_lower or "definition" in pun_lower:
        return pun_text, 0.0
    if "repealed" in pun_lower:
        return pun_text, 0.0

    if "death" in pun_lower:
        return pun_text, 10.0
    if "life" in pun_lower:
        return pun_text, 9.8

    for phrase, score in CROSS_REFERENCE_SEVERITY.items():
        if phrase in pun_lower:
            return pun_text, score

    max_months = _extract_max_imprisonment_months(pun_lower)
    if max_months is not None:
        severity = _duration_to_severity(max_months)
        if "fine" in pun_lower:
            severity = min(10.0, severity + 0.2)
        return pun_text, severity

    if "imprisonment" in pun_lower or "rigorous" in pun_lower or "simple imprisonment" in pun_lower:
        return pun_text, 6.0
    if "forfeiture" in pun_lower:
        return pun_text, 4.0
    if "fine" in pun_lower:
        return pun_text, 1.5

    return pun_text, 3.0

app = FastAPI()
templates = Jinja2Templates(directory="templates")

# ----------------- Load IPC Data -----------------
with open("ipc.json", "r", encoding="utf-8") as f:
    ipc_data = json.load(f)

texts = [
    f"Section {item['Section']} - {item['section_title']}: {item['section_desc']}"
    for item in ipc_data
]

print("Loading embedding model...")
model = SentenceTransformer("all-MiniLM-L6-v2")
embeddings = model.encode(texts, convert_to_numpy=True)
print("Embedding model loaded!")

print("Loading complaint model...")
generator = pipeline(
    "text2text-generation",
    model="google/flan-t5-base",
    max_new_tokens=200,
    do_sample=False
)
print("Complaint model ready!")

# ----------------- SERP SEARCH -----------------
SERP_API_KEY = "b1a1418e85f4c2a53e6479f526853f6199c597fe69e8130466569141e3cca5bb"

def search_indian_kanoon(query, num_results=5):
    url = "https://serpapi.com/search"
    params = {
        "engine": "google",
        "q": f"site:indiankanoon.org {query}",
        "hl": "en",
        "gl": "in",
        "num": num_results,
        "api_key": SERP_API_KEY
    }
    try:
        response = requests.get(url, params=params)
        data = response.json()
    except:
        return []

    results = []
    if "organic_results" in data:
        for result in data["organic_results"]:
            link = result.get("link", "")
            if "/doc/" in link:
                results.append({
                    "title": result.get("title"),
                    "link": link,
                    "snippet": result.get("snippet")
                })
    return results

# ----------------- AI Complaint Generator -----------------
def generate_incident(user_text: str) -> str:
    prompt = f"""You are a legal assistant drafting an FIR complaint.
Convert the following informal statement into a professional,
legally structured complaint paragraph.

Rules:
- First person
- One paragraph
- No date, time, or place
- Professional legal tone

User Statement:
{user_text}

Formal Complaint:"""

    output = generator(prompt)[0]["generated_text"]
    return re.sub(r"\s+", " ", output).strip()

# ----------------- Models -----------------
class ComplaintInput(BaseModel):
    complaint: str

class SectionInput(BaseModel):
    section: str

class GenerateInput(BaseModel):
    complaint: str
    section: Optional[str] = None
    ipc_sections: List[str] = []
    name: str
    address: str
    contact: str
    date: str
    time: str
    place: str


class ChatInput(BaseModel):
    question: str
    sections: List[str] = []


def _build_ipc_context_lines(selected_sections: List[str]) -> List[str]:
    matched = [item for item in ipc_data if str(item.get("Section", "")).strip() in selected_sections]
    lines = []
    for item in matched[:8]:
        sec = str(item.get("Section", "")).strip()
        title = str(item.get("section_title", "")).strip()
        desc = str(item.get("section_desc", "")).strip()
        pun = punishments.get(sec, "N/A")
        pun_display, score = get_severity(pun)
        lines.append(
            f"IPC Section {sec} - {title}\n"
            f"  Description: {desc}\n"
            f"  Punishment: {pun_display} | Severity: {round(score, 1)}/10"
        )
    return lines


def _build_ipc_display_lines(selected_sections: List[str]) -> List[str]:
    """Short version for display in fallback responses — section + title only."""
    matched = [item for item in ipc_data if str(item.get("Section", "")).strip() in selected_sections]
    lines = []
    for item in matched[:8]:
        sec = str(item.get("Section", "")).strip()
        title = str(item.get("section_title", "")).strip()
        pun = punishments.get(sec, "N/A")
        pun_display, score = get_severity(pun)
        lines.append(f"IPC {sec} — {title} | Punishment: {pun_display} | Severity: {round(score, 1)}/10")
    return lines


def _fallback_chat_response(question: str, lines: List[str]) -> str:
    q_lower = question.lower()
    legal_note = "This is basic legal guidance for awareness. Please consult a qualified advocate for case-specific advice."
    context = "\n".join(lines)
    disclaimer = "⚠ This is legal awareness information only. Always consult a qualified advocate for your specific case."

    if any(k in q_lower for k in ["bail", "anticipatory", "regular bail", "bailable"]):
        return (
            "⚖ Bail Analysis for Selected IPC Sections:\n\n"
            + context + "\n\n"
            + "Key Bail Points:\n"
            "• Offences punishable with death or life imprisonment are generally non-bailable.\n"
            "• Offences with punishment up to 3 years may be bailable at the discretion of a magistrate.\n"
            "• For non-bailable offences, bail must be applied for in Sessions Court or High Court.\n"
            "• Anticipatory bail (Sec 438 CrPC) can be applied before arrest if apprehension of arrest exists.\n"
            "• Factors considered: criminal history, flight risk, evidence tampering, gravity of offence.\n\n"
            "Next Steps: Engage an advocate, prepare personal sureties, draft bail application with facts.\n\n"
            + disclaimer
        )

    if any(k in q_lower for k in ["punishment", "sentence", "jail", "imprisonment", "penalty", "severity"]):
        return (
            "⚖ Punishment Overview for Selected IPC Sections:\n\n"
            + context + "\n\n"
            "Key Points on Punishment:\n"
            "• Punishment is awarded based on the severity of the offence and circumstances.\n"
            "• Courts may award minimum, maximum, or concurrent sentences for multiple offences.\n"
            "• Good conduct, first-time offence, and cooperation with investigation can reduce sentencing.\n"
            "• Fines and imprisonment may be awarded together depending on the section.\n\n"
            + disclaimer
        )

    if any(k in q_lower for k in ["fir", "complaint", "police", "register", "station", "file"]):
        return (
            "⚖ FIR / Complaint Filing Guidance:\n\n"
            "Relevant IPC Sections:\n" + context + "\n\n"
            "Steps to File an FIR:\n"
            "1. Visit the nearest police station and approach the Station House Officer (SHO).\n"
            "2. Narrate the incident clearly — date, time, place, persons involved.\n"
            "3. Mention the applicable IPC sections from the predicted list.\n"
            "4. FIR is a right — police cannot refuse to register a cognizable offence (Sec 154 CrPC).\n"
            "5. If refused, you can approach the Superintendent of Police or file a complaint in Magistrate Court.\n"
            "6. Collect a signed copy of the FIR — it is your legal right.\n"
            "7. Preserve evidence: medical reports, photos, witness contacts, digital records.\n\n"
            + disclaimer
        )

    if any(k in q_lower for k in ["arrest", "arrested", "custody", "rights", "right"]):
        return (
            "⚖ Rights During Arrest (Indian Law):\n\n"
            "Relevant Sections:\n" + context + "\n\n"
            "Your Rights:\n"
            "• Right to know grounds of arrest (Art 22, Constitution).\n"
            "• Right to consult and be defended by a lawyer of your choice.\n"
            "• Right to be produced before a Magistrate within 24 hours.\n"
            "• Right to inform a friend or relative about the arrest.\n"
            "• Right against self-incrimination — you cannot be forced to testify against yourself.\n"
            "• Right to medical examination (Sec 54 CrPC).\n\n"
            + disclaimer
        )

    if any(k in q_lower for k in ["evidence", "proof", "witness", "document"]):
        return (
            "⚖ Evidence Guidance:\n\n"
            "Relevant Sections:\n" + context + "\n\n"
            "Evidence Tips:\n"
            "• Preserve all documentary evidence: photos, videos, medical reports, receipts, messages.\n"
            "• Witness statements should be recorded promptly and kept safe.\n"
            "• Digital evidence (screenshots, call records) is admissible under IT Act and Indian Evidence Act.\n"
            "• Do not tamper with or destroy evidence — this is itself a punishable offence.\n"
            "• Police are empowered to seize evidence during investigation under CrPC.\n\n"
            + disclaimer
        )

    if any(k in q_lower for k in ["what is", "explain", "define", "describe", "mean", "section"]):
        return (
            "⚖ Section Explanation:\n\n"
            + context + "\n\n"
            "These IPC sections were predicted as most relevant to your complaint. "
            "Each section covers a specific type of offence with defined punishments. "
            "You can click 'Select & Fetch Judgements' on any section card to see real court cases.\n\n"
            + disclaimer
        )

    return (
        "⚖ Legal Agent Response:\n\n"
        "Based on your selected IPC sections:\n\n"
        + context + "\n\n"
        "I can help you with:\n"
        "• Punishment & severity details\n"
        "• Bail eligibility & process\n"
        "• FIR filing steps\n"
        "• Arrest rights\n"
        "• Evidence guidance\n"
        "• Section explanations\n\n"
        "Try asking: 'What is the punishment?', 'Can I get bail?', 'How do I file an FIR?'\n\n"
        + disclaimer
    )


def _gemini_chat_response(question: str, lines: List[str]) -> tuple[Optional[str], Optional[str]]:
    api_key = _get_gemini_api_key()
    if not api_key:
        return None, "missing_api_key"

    prompt = (
        "You are a knowledgeable legal awareness assistant for Indian law (IPC - Indian Penal Code). "
        "Answer the user's question using the exact IPC section data provided below, including section descriptions, punishments, and severity. "
        "Be concise, factual, and helpful. Do not fabricate any legal information not present in the context. "
        "End every response with: 'Note: Please consult a qualified advocate for legal advice specific to your case.'\n\n"
        "IPC Section Data:\n"
        "---\n"
        + "\n\n".join(lines)
        + "\n---\n\n"
        "User Question: " + question
    )

    payload = {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {"temperature": 0.3, "maxOutputTokens": 512},
        "safetySettings": [
            {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_ONLY_HIGH"},
            {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_ONLY_HIGH"},
        ]
    }

    for model_name in ["gemini-2.0-flash-lite", "gemini-2.0-flash", "gemini-2.5-flash", "gemini-flash-latest"]:
        try:
            url = f"https://generativelanguage.googleapis.com/v1beta/models/{model_name}:generateContent?key={api_key}"
            response = requests.post(url, json=payload, timeout=20)

            if response.status_code == 429:
                continue  # try next model

            if response.status_code != 200:
                return None, f"gemini_error_{response.status_code}"

            data = response.json()
            candidates = data.get("candidates", [])
            if candidates:
                text = candidates[0].get("content", {}).get("parts", [{}])[0].get("text", "").strip()
                if text:
                    return text, None

        except Exception:
            continue

    return None, "gemini_request_failed"

# ----------------- Routes -----------------
@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse(request, "index.html")


@app.get("/sections")
async def list_sections(q: str = "", limit: int = 50):
    query = q.strip().lower()
    safe_limit = max(1, min(limit, 200))

    rows = []
    for item in ipc_data:
        sec = str(item.get("Section", "")).strip()
        title = str(item.get("section_title", "")).strip()
        if query and query not in sec.lower() and query not in title.lower():
            continue
        rows.append({"section": sec, "title": title})

    rows.sort(key=lambda r: (int(re.match(r"^\d+", r["section"]).group(0)) if re.match(r"^\d+", r["section"]) else 10**9, r["section"]))
    return {"sections": rows[:safe_limit]}


@app.post("/ipc-chat")
async def ipc_chat(data: ChatInput):
    question = str(data.question or "").strip()
    if not question:
        return {"answer": "Please ask a question about the selected IPC sections."}

    selected_sections = []
    for sec in data.sections or []:
        sec_value = str(sec).strip()
        if sec_value and sec_value not in selected_sections:
            selected_sections.append(sec_value)

    lines = _build_ipc_context_lines(selected_sections)
    display_lines = _build_ipc_display_lines(selected_sections)
    if not lines:
        return {"answer": "No IPC sections are selected yet. Predict or add sections first, then ask your question."}

    groq_answer, groq_error = _groq_chat_response(question, lines)
    if groq_answer:
        return {"answer": groq_answer, "mode": "groq"}

    gemini_answer, gemini_error = _gemini_chat_response(question, lines)
    if gemini_answer:
        return {"answer": gemini_answer, "mode": "gemini"}

    return {"answer": _fallback_chat_response(question, display_lines), "mode": "fallback", "reason": groq_error}

@app.post("/predict")
async def predict(data: ComplaintInput):
    query_vec = model.encode([data.complaint], convert_to_numpy=True)
    sims = cosine_similarity(query_vec, embeddings)[0]
    top_indices = sims.argsort()[-3:][::-1]
    
    # ENHANCED WITH PUNISHMENTS + SEVERITY
    sections_out = []
    for idx in top_indices:
        sec = ipc_data[idx].copy()
        sec_key = str(sec['Section'])
        pun_raw = punishments.get(sec_key, "N/A")
        pun_display, severity_score = get_severity(pun_raw)
        sec['punishment'] = pun_display
        sec['severity_score'] = round(severity_score, 1)
        sections_out.append(sec)
    return {"sections": sections_out}

@app.post("/judgements")
async def judgements(data: SectionInput):
    selected = next(
        (item for item in ipc_data if str(item["Section"]) == str(data.section)),
        None
    )

    if not selected:
        return {"results": []}

    query = f"IPC Section {selected['Section']} {selected['section_title']}"
    results = search_indian_kanoon(query)
    return {"results": results}

@app.post("/generate")
async def generate(data: GenerateInput):

    sections = [str(s).strip() for s in (data.ipc_sections or []) if str(s).strip()]
    if not sections and data.section:
        section_value = str(data.section).strip()
        if section_value:
            sections = [section_value]

    if not sections:
        return {"error": "Please provide at least one IPC section."}

    section_text = ", ".join(sections)

    incident = generate_incident(data.complaint)

    doc = Document()

    # -------- REMOVE EXTRA SPACING --------
    style = doc.styles['Normal']
    style.paragraph_format.space_after = Pt(0)
    style.paragraph_format.space_before = Pt(0)

    # -------- TITLE --------
    title = doc.add_paragraph()
    run = title.add_run("COMPLAINT LETTER")
    run.bold = True
    run.font.size = Pt(16)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER

    doc.add_paragraph("")

    # -------- ADDRESS --------
    doc.add_paragraph("To,")
    doc.add_paragraph("The Station House Officer")
    doc.add_paragraph(f"{data.place} Police Station")
    doc.add_paragraph("")

    # -------- SUBJECT --------
    subject = doc.add_paragraph()
    run = subject.add_run(
        f"Subject: Complaint under IPC Section(s) {section_text}"
    )
    run.bold = True

    doc.add_paragraph("")
    doc.add_paragraph("Respected Sir/Madam,")
    doc.add_paragraph("")

    # -------- INTRO --------
    intro = (
        f"I, {data.name}, residing at {data.address}, "
        "respectfully submit this complaint for your kind consideration."
    )
    doc.add_paragraph(intro)
    doc.add_paragraph("")

    # -------- INCIDENT --------
    heading = doc.add_paragraph()
    run = heading.add_run("Facts of the Incident:")
    run.bold = True

    doc.add_paragraph("")
    doc.add_paragraph(
        f"On {data.date} at approximately {data.time} at {data.place}, "
        "the following incident occurred:"
    )
    doc.add_paragraph("")
    doc.add_paragraph(incident)
    doc.add_paragraph("")

    # -------- LEGAL REQUEST --------
    legal = doc.add_paragraph()
    run = legal.add_run("Legal Grounds and Prayer:")
    run.bold = True

    doc.add_paragraph("")
    doc.add_paragraph(
        f"The above act constitutes offences punishable under IPC Section(s) "
        f"{section_text}. "
        "I request you to kindly register this complaint as an FIR and "
        "take appropriate legal action against the accused person(s)."
    )

    doc.add_paragraph("")
    doc.add_paragraph("I shall cooperate fully with the investigation.")
    doc.add_paragraph("")

    # -------- THANKING YOU (CENTER) --------
    thanks = doc.add_paragraph("Thanking you.")
    thanks.alignment = WD_ALIGN_PARAGRAPH.CENTER

    doc.add_paragraph("")

    # -------- SIGNATURE --------
    signature = doc.add_paragraph()
    signature.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    signature.add_run("Yours faithfully,\n").bold = True
    signature.add_run(f"{data.name}\n")
    signature.add_run(f"Address: {data.address}\n")
    signature.add_run(f"Contact: {data.contact}\n")
    signature.add_run(f"Date: {datetime.date.today()}")

    filename = "criminal_complaint.docx"
    doc.save(filename)

    return {"file_url": f"/download/{filename}"}

@app.get("/download/{filename}")
async def download(filename: str):
    return FileResponse(
        filename,
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    )
# ----------------- Load Bail Dataset -----------------
with open("bail_judgments.json", "r", encoding="utf-8") as f:
    bail_cases = json.load(f)
def search_bail_cases(ipc_section, top_k=3):

    ipc_section = str(ipc_section)

    matched_cases = [
        case for case in bail_cases
        if ipc_section in case.get("ipc_sections", [])  # <-- check correct key name
    ]

    return matched_cases[:top_k]

@app.post("/bail")
async def bail(data: SectionInput):

    section_number = str(data.section)

    results = search_bail_cases(section_number)

    return {"results": results}



# import json
# import requests
# from sentence_transformers import SentenceTransformer
# from sklearn.metrics.pairwise import cosine_similarity
# from transformers import pipeline
# from docx import Document
# import datetime
# import os
# import re
#
# # ----------------- Load IPC Data -----------------
# with open("ipc.json", "r", encoding="utf-8") as f:
#     ipc_data = json.load(f)
#
# texts = [
#     f"Section {item['Section']} - {item['section_title']}: {item['section_desc']}"
#     for item in ipc_data
# ]
#
# # ----------------- Load Embedding Model -----------------
# print("Loading embedding model...")
# model = SentenceTransformer('all-MiniLM-L6-v2')
# embeddings = model.encode(texts, convert_to_numpy=True)
# print("Model loaded!\n")
#
# # ----------------- Load Complaint Generator -----------------
# print("Loading complaint writing model...")
# generator = pipeline(
#     "text2text-generation",
#     model="google/flan-t5-small",
#     max_new_tokens=120,
#     do_sample=False
# )
# print("Complaint model ready!\n")
#
# # ----------------- SERP API -----------------
# SERP_API_KEY = "b1a1418e85f4c2a53e6479f526853f6199c597fe69e8130466569141e3cca5bb"
#
# def search_indian_kanoon(query, num_results=5):
#     url = "https://serpapi.com/search"
#     params = {
#         "engine": "google",
#         "q": f"site:indiankanoon.org {query}",
#         "hl": "en",
#         "gl": "in",
#         "num": num_results,
#         "api_key": SERP_API_KEY
#     }
#
#     try:
#         response = requests.get(url, params=params)
#         data = response.json()
#     except Exception as e:
#         print("Error fetching judgements:", e)
#         return []
#
#     results = []
#     if "organic_results" in data:
#         for result in data["organic_results"]:
#             link = result.get("link", "")
#             if "/doc/" in link:
#                 results.append({
#                     "title": result.get("title"),
#                     "link": link,
#                     "snippet": result.get("snippet")
#                 })
#
#     return results
#
#
# # ----------------- Generate Incident -----------------
# def generate_incident(user_text: str) -> str:
#     prompt = f"""
# Rewrite the following statement as a formal police complaint incident description.
#
# Rules:
# - Write in FIRST PERSON
# - Use formal legal language
# - One paragraph only
# - Do NOT include date, time or place
#
# User statement:
# "{user_text}"
#
# Formal incident description:
# """
#     output = generator(prompt)[0]["generated_text"]
#     output = re.sub(r'\s+', ' ', output).strip()
#     return output
#
#
# # ----------------- MAIN -----------------
# def main():
#
#     print("========== IPC + Judgement + Complaint Generator ==========\n")
#
#     # STEP 1: Complaint Input
#     complaint = input("Enter your complaint: ").strip()
#
#     # STEP 2: Predict IPC Sections
#     query_vec = model.encode([complaint], convert_to_numpy=True)
#     sims = cosine_similarity(query_vec, embeddings)[0]
#     top_indices = sims.argsort()[-3:][::-1]
#
#     print("\n--- Top 3 Predicted IPC Sections ---\n")
#
#     top_sections = []
#     for rank, idx in enumerate(top_indices, start=1):
#         sec = ipc_data[idx]
#         print(f"{rank}. Chapter {sec['chapter']} - {sec['chapter_title']}")
#         print(f"   Section {sec['Section']} - {sec['section_title']}")
#         print("-" * 70)
#         top_sections.append(sec)
#
#     # STEP 3: Select Section
#     choice = int(input("Select section number (1/2/3): ")) - 1
#     selected_section = top_sections[choice]
#
#     print(f"\nSelected IPC Section: {selected_section['Section']}\n")
#
#     # STEP 4: Fetch Judgements for selected section
#     print("Searching relevant court judgements...\n")
#
#     ipc_query = f"IPC Section {selected_section['Section']} {selected_section['section_title']}"
#     results = search_indian_kanoon(ipc_query)
#
#     if results:
#         print("---- Court Judgements ----\n")
#         for i, res in enumerate(results, start=1):
#             print(f"Result {i}")
#             print("Title:", res["title"])
#             print("Link:", res["link"])
#             print("Snippet:", res["snippet"])
#             print("-" * 80)
#     else:
#         print("No court judgements found or API limit reached.\n")
#
#     # STEP 5: Generate Complaint Text
#     print("\nGenerating professional complaint...\n")
#     incident_text = generate_incident(complaint)
#
#     # STEP 6: Collect Personal Details
#     name = input("Name: ")
#     address = input("Address: ")
#     contact = input("Contact Number: ")
#     date = input("Incident Date (DD-MM-YYYY): ")
#     time = input("Incident Time: ")
#     place = input("Incident Place: ")
#
#     # STEP 7: Create DOCX
#     doc = Document()
#
#     doc.add_paragraph(
#         "To\n"
#         "The Station House Officer\n"
#         "Concerned Police Station\n"
#         "City, State\n\n"
#         f"Subject: Complaint under Section {selected_section['Section']} IPC\n\n"
#     )
#
#     body = f"""
# Respected Sir/Madam,
#
# I, {name}, residing at {address}, hereby submit this complaint under Section {selected_section['Section']} of the Indian Penal Code.
#
# On {date} at around {time}, at {place}, the following incident occurred:
#
# {incident_text}
#
# I respectfully request you to register this complaint and take necessary legal action in accordance with law.
#
# Thanking you.
#
# Yours faithfully,
# {name}
# Contact: {contact}
# Date: {datetime.date.today()}
# """
#
#     doc.add_paragraph(body)
#
#     filename = "criminal_complaint.docx"
#     filepath = os.path.abspath(filename)
#     doc.save(filename)
#
#     print("\nCOMPLAINT GENERATED SUCCESSFULLY")
#     print("Saved at:", filepath)
#
#
# if __name__ == "__main__":
#     main()


# import json
# import requests
# from sentence_transformers import SentenceTransformer
# from sklearn.metrics.pairwise import cosine_similarity
#
# # ----------------- Load IPC Data -----------------
# with open("ipc.json", "r", encoding="utf-8") as f:
#     ipc_data = json.load(f)
#
# texts = [
#     f"Section {item['Section']} - {item['section_title']}: {item['section_desc']}"
#     for item in ipc_data
# ]
#
# # ----------------- Load Embedding Model -----------------
# print("Loading embedding model...")
# model = SentenceTransformer('all-MiniLM-L6-v2')
# embeddings = model.encode(texts, convert_to_numpy=True)
# print("Model loaded! Ready to predict IPC sections and search judgements.\n")
#
# # ----------------- SERP API Setup -----------------
# SERP_API_KEY = "b1a1418e85f4c2a53e6479f526853f6199c597fe69e8130466569141e3cca5bb"
#
# def search_indian_kanoon(query, num_results=10):
#     """
#     Search Indian Kanoon via SerpAPI and return only court judgements.
#     Judgement links on Indiankanoon contain '/doc/' in URL.
#     """
#     url = "https://serpapi.com/search"
#     params = {
#         "engine": "google",
#         "q": f"site:indiankanoon.org {query}",
#         "hl": "en",
#         "gl": "in",
#         "num": num_results,
#         "api_key": SERP_API_KEY
#     }
#     try:
#         response = requests.get(url, params=params)
#         data = response.json()
#     except Exception as e:
#         print("Error fetching results:", e)
#         return []
#
#     results = []
#     if "organic_results" in data:
#         for result in data["organic_results"]:
#             link = result.get("link", "")
#             # Filter only actual court judgements
#             if "/doc/" in link:
#                 results.append({
#                     "title": result.get("title"),
#                     "link": link,
#                     "snippet": result.get("snippet")
#                 })
#     return results
#
# # ----------------- Terminal Query Loop -----------------
# def main():
#     print("Welcome to IPC + Court Judgement Search (Indian Kanoon)")
#     print("Type your complaint and get relevant IPC sections and court judgements.\n")
#
#     while True:
#         complaint = input("Enter your complaint (or type 'exit' to quit): ").strip()
#         if complaint.lower() == "exit":
#             print("Goodbye!")
#             break
#
#         # --- Step 1: Predict top 3 IPC sections ---
#         query_vec = model.encode([complaint], convert_to_numpy=True)
#         sims = cosine_similarity(query_vec, embeddings)[0]
#         top_indices = sims.argsort()[-3:][::-1]  # top 3 sections
#
#         print("\n--- Top 3 Predicted IPC Sections ---\n")
#         top_sections = []
#         for rank, idx in enumerate(top_indices, start=1):
#             sec = ipc_data[idx]
#             print(f"{rank}. Chapter {sec['chapter']} - {sec['chapter_title']}")
#             print(f"   Section {sec['Section']} - {sec['section_title']}")
#             print(f"   Description: {sec['section_desc']}")
#             print("-"*80)
#             top_sections.append(sec)
#
#         # --- Step 2: Ask user which section(s) they want judgements for ---
#         choices = input(
#             "Enter the number(s) of the section(s) you want judgements for (e.g., 1 or 1,3): "
#         ).strip()
#         chosen_indices = [int(x)-1 for x in choices.split(",") if x.strip().isdigit()]
#
#         # --- Step 3: Fetch judgements only for chosen section(s) ---
#         print("\n--- Relevant Court Judgements ---\n")
#         for i in chosen_indices:
#             sec = top_sections[i]
#             ipc_query = f"IPC Section {sec['Section']} {sec['section_title']}"
#             print(f"Searching judgements for: {ipc_query}\n")
#             results = search_indian_kanoon(ipc_query)
#
#             if not results:
#                 print("No court judgements found or API limit reached.\n")
#                 continue
#
#             for j, res in enumerate(results, start=1):
#                 print(f"Result {j}")
#                 print("Title:", res["title"])
#                 print("Link:", res["link"])
#                 print("Snippet:", res["snippet"])
#                 print("-"*80)
#         print("\n")
#
# if __name__ == "__main__":
#     main()
#

# import json
# import requests
# from sentence_transformers import SentenceTransformer
# from sklearn.metrics.pairwise import cosine_similarity
#
# # ----------------- Load IPC Data -----------------
# with open("ipc.json", "r", encoding="utf-8") as f:
#     ipc_data = json.load(f)
#
# texts = [
#     f"Section {item['Section']} - {item['section_title']}: {item['section_desc']}"
#     for item in ipc_data
# ]
#
# # ----------------- Load Embedding Model -----------------
# print("Loading embedding model...")
# model = SentenceTransformer('all-MiniLM-L6-v2')
# embeddings = model.encode(texts, convert_to_numpy=True)
# print("Model loaded! Ready to search IPC sections.\n")
#
# # ----------------- SERP API Setup -----------------
# SERP_API_KEY = "b1a1418e85f4c2a53e6479f526853f6199c597fe69e8130466569141e3cca5bb"
#
# def search_indian_kanoon(query, num_results=3):
#     url = "https://serpapi.com/search"
#     params = {
#         "engine": "google",
#         "q": f"site:indiankanoon.org {query}",
#         "hl": "en",
#         "gl": "in",
#         "num": num_results,
#         "api_key": SERP_API_KEY
#     }
#     response = requests.get(url, params=params)
#     data = response.json()
#     results = []
#     if "organic_results" in data:
#         for result in data["organic_results"]:
#             results.append({
#                 "title": result.get("title"),
#                 "link": result.get("link"),
#                 "snippet": result.get("snippet")
#             })
#     return results
#
# # ----------------- Terminal Query Loop -----------------
# while True:
#     complaint = input("Enter your complaint (or type 'exit' to quit): ").strip()
#     if complaint.lower() == 'exit':
#         print("Goodbye!")
#         break
#
#     # --- Step 1: Find top 3 IPC sections ---
#     query_vec = model.encode([complaint], convert_to_numpy=True)
#     sims = cosine_similarity(query_vec, embeddings)[0]
#     top_indices = sims.argsort()[-3:][::-1]  # top 3 sections
#
#     print("\n--- Top IPC Sections ---\n")
#     ipc_queries = []
#     for idx in top_indices:
#         sec = ipc_data[idx]
#         print(f"Chapter {sec['chapter']} - {sec['chapter_title']}")
#         print(f"Section {sec['Section']} - {sec['section_title']}")
#         print(f"Description: {sec['section_desc']}")
#         print("-"*80)
#         ipc_queries.append(f"IPC Section {sec['Section']} {sec['section_title']}")
#
#     # --- Step 2: Search Indian Kanoon for each IPC section ---
#     print("\n--- Relevant Judgements ---\n")
#     for ipc_query in ipc_queries:
#         print(f"Searching judgements for: {ipc_query}")
#         results = search_indian_kanoon(ipc_query)
#         if not results:
#             print("No judgements found or API limit reached.")
#         for i, res in enumerate(results, start=1):
#             print(f"Result {i}")
#             print("Title:", res['title'])
#             print("Link:", res['link'])
#             print("Snippet:", res['snippet'])
#             print("-"*60)
#     print("\n\n")
#
# # import requests
# #
# # SERP_API_KEY = "b1a1418e85f4c2a53e6479f526853f6199c597fe69e8130466569141e3cca5bb"
# #
# # def search_indian_kanoon(query):
# #     url = "https://serpapi.com/search"
# #
# #     params = {
# #         "engine": "google",
# #         "q": f"site:indiankanoon.org {query}",
# #         "hl": "en",
# #         "gl": "in",
# #         "num": 5,
# #         "api_key": SERP_API_KEY
# #     }
# #
# #     response = requests.get(url, params=params)
# #     data = response.json()
# #
# #     if "organic_results" not in data:
# #         print("No results found or API limit reached")
# #         return
# #
# #     for i, result in enumerate(data["organic_results"], start=1):
# #         print(f"\nResult {i}")
# #         print("Title:", result.get("title"))
# #         print("Link:", result.get("link"))
# #         print("Explanation:", result.get("snippet"))
# #
# #
# # # -------- TEST ----------
# # if __name__ == "__main__":
# #     query = input("Enter legal query: ")
# #     search_indian_kanoon(query)
