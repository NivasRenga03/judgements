import json
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity

# ----------------- Load IPC Data -----------------
with open("ipc.json", "r", encoding="utf-8") as f:
    ipc_data = json.load(f)

# Combine section info into a single string for embedding
texts = [
    f"Section {item['Section']} - {item['section_title']}: {item['section_desc']}"
    for item in ipc_data
]

# ----------------- Load Embedding Model -----------------
print("Loading embedding model... (this may take a few seconds)")
model = SentenceTransformer('all-MiniLM-L6-v2')
embeddings = model.encode(texts, convert_to_numpy=True)
print("Model loaded! Ready to search IPC sections.\n")

# ----------------- Terminal Query Loop -----------------
while True:
    query = input("Enter your legal query (or type 'exit' to quit): ").strip()
    if query.lower() == 'exit':
        print("Goodbye!")
        break

    # Encode query
    query_vec = model.encode([query], convert_to_numpy=True)

    # Compute similarity
    sims = cosine_similarity(query_vec, embeddings)[0]

    # Get top 5 sections
    top_indices = sims.argsort()[-5:][::-1]

    print("\nTop relevant IPC sections:\n")
    for idx in top_indices:
        sec = ipc_data[idx]
        print(f"Chapter {sec['chapter']} - {sec['chapter_title']}")
        print(f"Section {sec['Section']} - {sec['section_title']}")
        print(f"Description: {sec['section_desc']}")
        print("-"*80)
    print("\n")
